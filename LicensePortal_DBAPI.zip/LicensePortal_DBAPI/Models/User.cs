﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicensePortal_DBAPI.Models
{
    public class User
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string City { get; set; }
    }
}
