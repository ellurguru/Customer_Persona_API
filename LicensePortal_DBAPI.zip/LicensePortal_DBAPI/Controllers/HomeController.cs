﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using LicensePortal_DBAPI.Models;
using LicensePortal_DBAPI.Utilities;


namespace LicensePortal_DBAPI.Controllers
{
    
    [ApiController]
    public class HomeController : ControllerBase
    {

        //string decrypted = Decrypt(encrypted, tdes.Key, tdes.IV);
        [Route("api/GetUsers")]
        public async Task<string> GetUsers()
        {
            IList <User> obIjuser= new List<User>();
            User objuser = new User();
            objuser.Id = "1";
            objuser.Name = "Guru";
            objuser.EmailID = "gururaj.e@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "2";
            objuser.Name = "Ravi";
            objuser.EmailID = "ravi@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "3";
            objuser.Name = "Kuntal";
            objuser.EmailID = "kuntal@slkgroup.com";
            objuser.City = "Pune";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "4";
            objuser.Name = "Praveen";
            objuser.EmailID = "praveen@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "5";
            objuser.Name = "Pooja";
            objuser.EmailID = "pooja@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "6";
            objuser.Name = "Shiva";
            objuser.EmailID = "shiva@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            string objson=TripleDES.ToJSONString(obIjuser);
            var encryptedText = TripleDES.Encrypt(objson);
            return await Task.FromResult(encryptedText);
        }

        [Route("api/GetUserById/{userid}")]
        public async Task<string> GetUserById(string userid)
        {
            var userid_esc= TripleDES.FromHexString(userid);

            var decryptUserid = TripleDES.Decrypt(userid_esc);
            
            IList<User> obIjuser = new List<User>();

            User objuser = new User();
            objuser.Id = "1";
            objuser.Name = "Guru";
            objuser.EmailID = "gururaj.e@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "2";
            objuser.Name = "Ravi";
            objuser.EmailID = "ravi@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "3";
            objuser.Name = "Kuntal";
            objuser.EmailID = "kuntal@slkgroup.com";
            objuser.City = "Pune";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "4";
            objuser.Name = "Praveen";
            objuser.EmailID = "praveen@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "5";
            objuser.Name = "Pooja";
            objuser.EmailID = "pooja@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            objuser = new User();
            objuser.Id = "6";
            objuser.Name = "Shiva";
            objuser.EmailID = "shiva@slkgroup.com";
            objuser.City = "Bangalore";
            obIjuser.Add(objuser);

            string objson = TripleDES.ToJSONString(obIjuser.Where(p=>p.Id == decryptUserid).ToList());
            var encryptedText = TripleDES.Encrypt(objson);
            return await Task.FromResult(encryptedText);
        }
    }
}
