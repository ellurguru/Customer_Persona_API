﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LicensePortal_APPAPI.Models
{
    public class LicenseInfo
    {
        /// <summary>
        /// Gets or sets UserName.
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets EmailId.
        /// </summary>
        public string EmailId { get; set; }

        /// <summary>
        /// Gets or sets LicenseType.
        /// </summary>
        public string LicenseType { get; set; }

        /// <summary>
        /// Gets or sets StartDate.
        /// </summary>

        public string StartDate { get; set; }
        /// <summary>
        /// Gets or sets ExpiryDate.
        /// </summary>
        public string EndDate { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate.
        /// </summary>
        public string Product { get; set; }
        public string CustList { get; set; }

        //public IEnumerable<ProductFeatures> CustList { get; set; }
    }
}
